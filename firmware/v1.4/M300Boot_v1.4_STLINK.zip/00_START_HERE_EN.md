# M300Boot 1.4 — ST-Link installation

Classic M300, qualified HW05/PCB Rev.5.3 profile, 256 KiB Flash.
This package contains two BOOT segments and does not install Klipper.

1. Take two independent complete 256-KiB Flash reads and read UID and Option Bytes. Keep the originals from this printer.
2. Generate a checked offline plan before programming:

```sh
python3 tools/stlink_preflight.py plan --backup-a FLASH_A.bin --backup-b FLASH_B.bin --uid UID.bin --options OPTIONS.bin --out-dir PRIVATE_PLAN
```

The utility requires a recognized source and RDP ALREADY disabled. Do not disable protection to bypass refusal: it can erase Flash. Resolve any refusal before proceeding.
3. Keep the MCU halted. Program and verify ASSETS at 0x0803A000 (12288 bytes) first, then STAGE2 at 0x08001000 (28672 bytes). Use only those two BIN files and their corresponding pages. Never use Mass Erase, a full 256-KiB write, or Option Byte changes.
4. Read all 256 KiB again. Use the utility's verify command; see --help for its required arguments. Every byte outside the two segments, including APP, both settings journals, the first 4 KiB and NVM, must remain identical.
5. Run the MCU only after verification passes. Open Diagnostics → UART. Empty settings default to 250000 and UART on bootwait OFF. Existing supported settings are retained. If the old saved value was 19200, 57600 or 1000000, BOOT runs at 250000; explicitly select and save 250000 before starting an older Klipper application.
6. Set the host to the same baud. ST-Link preserves the application, so no SD intermediary installation is needed afterwards.

Version 1.4 has passed computer validation; physical printer acceptance remains pending.
Full instructions: https://github.com/MarcinKowalik-AGH/Zortrax-m300-Boot-Loader/blob/main/docs/en/v1.4/stlink-and-recovery.md
