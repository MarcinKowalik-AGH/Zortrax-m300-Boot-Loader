# M300Boot 1.4 — instalacja przez ST-Link

Klasyczna M300, kwalifikowany profil HW05/PCB Rev.5.3, 256 KiB Flash.
To pakiet dwóch segmentów BOOT; nie zawiera aplikacji Klippera.

1. Wykonaj dwa niezależne odczyty całych 256 KiB Flash oraz odczyty UID i Option Bytes. Zachowaj oryginały na komputerze. Muszą należeć do tej drukarki.
2. Użyj narzędzia planującego przed zapisem:

```sh
python3 tools/stlink_preflight.py plan --backup-a FLASH_A.bin --backup-b FLASH_B.bin --uid UID.bin --options OPTIONS.bin --out-dir PRIVATE_PLAN
```

Narzędzie wymaga rozpoznanego źródła i wyłączonej JUŻ ochrony RDP. Nie wyłączaj ochrony tylko po to, aby ominąć odmowę; może to skasować Flash. Odmowę wyjaśnij przed kontynuacją.
3. Zachowaj zatrzymany MCU. Wgraj i zweryfikuj najpierw ASSETS pod 0x0803A000 (12288 B), następnie STAGE2 pod 0x08001000 (28672 B). Używaj wyłącznie dwóch wskazanych plików BIN i kasowania odpowiadających im stron. Nie używaj Mass Erase, zapisu pełnych 256 KiB ani zmiany Option Bytes.
4. Wykonaj odczyt całych 256 KiB. Sprawdź go narzędziem verify z --help. Wszystkie bajty poza dwoma segmentami, w tym APP, oba dzienniki ustawień, pierwsze 4 KiB i NVM, muszą pozostać identyczne.
5. Uruchom MCU dopiero po pozytywnej weryfikacji. Wejdź do Diagnostics → UART. Domyślne ustawienie to 250000, UART on bootwait OFF. Obsługiwane istniejące ustawienia pozostają zapisane. Gdy dawniej było 19200, 57600 albo 1000000, BOOT działa przy 250000; wybierz i zapisz 250000 przed uruchomieniem starszej aplikacji Klippera.
6. Ustaw identyczne baud w konfiguracji hosta. ST-Link zachowuje aplikację, więc nie wykonuj dodatkowej instalacji pośrednika SD.

Nowa wersja 1.4 została zweryfikowana komputerowo; jej test na fizycznej drukarce pozostaje do wykonania.
Pełne instrukcje: https://github.com/MarcinKowalik-AGH/Zortrax-m300-Boot-Loader/blob/main/docs/pl/v1.4/stlink-and-recovery.md
