# Corresponding MCU source

[Polski](README_PL.md)

This directory contains the custom MCU overlay, upstream patcher, build
configuration, build/verification tools and the R14-to-R14.2 delta.
The included MCU was built from these changes and this verified Klipper base:

- Commit: `ee2c6fb6b00b2b5d097ef70d0868df7d74943b51`.
- Base ZIP SHA-256: `fe4c6a25c370c32f519a008e46e14612ddb116a5ac135146afeee7d0bc4c2bf0`.
- The verified base archive is the existing SDK's `UPSTREAM_KLIPPER_PINNED.zip`;
  it is not duplicated in this update.

Use an ARM GNU toolchain with newlib-nano, make and Python 3:

```sh
python3 tools/build.py --archive /path/to/UPSTREAM_KLIPPER_PINNED.zip \
  --work /path/to/private-build --output /path/to/output \
  --toolchain-dir /path/to/arm-toolchain/bin --jobs 4
python3 tools/test01_m3b.py pack /path/to/output/klipper.bin /path/to/output/M300APP.M3B
```

The build creates and patches a private upstream checkout; it never flashes.
For a split-distribution toolchain, its newlib headers must also be on
`C_INCLUDE_PATH`. See `MCU/TOOLCHAIN.json` and `MCU/FULL_ARM_BUILD.log` for
the actual build environment. Build metadata and paths can vary between builds.

`R14_TO_R14_2.patch` is relative to the R14 custom source kit, not upstream
Klipper. It changes seven files; the custom board and STEP guard implementation
are unchanged. The cooling include holds the functional MCU correction.
The main project is GPL-3.0-or-later; see the package's `COPYING`.
