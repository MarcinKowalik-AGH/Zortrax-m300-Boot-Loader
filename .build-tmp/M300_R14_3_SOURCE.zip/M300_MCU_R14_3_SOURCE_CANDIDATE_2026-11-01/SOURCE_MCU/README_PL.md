# Źródła MCU

[English](README.md)

Katalog zawiera nakładkę źródeł MCU, skrypt zmian w upstream, konfigurację,
narzędzia kompilacji/weryfikacji i różnicę R14–R14.2.
Dołączone MCU skompilowano z tych zmian oraz sprawdzonej bazy Klippera:

- Commit: `ee2c6fb6b00b2b5d097ef70d0868df7d74943b51`.
- SHA-256 archiwum bazy: `fe4c6a25c370c32f519a008e46e14612ddb116a5ac135146afeee7d0bc4c2bf0`.
- Sprawdzone archiwum to `UPSTREAM_KLIPPER_PINNED.zip` z obecnego SDK;
  aktualizacja nie powiela tego archiwum.

Wymagane są ARM GNU z newlib-nano, make i Python 3:

```sh
python3 tools/build.py --archive /sciezka/UPSTREAM_KLIPPER_PINNED.zip \
  --work /sciezka/prywatna-kompilacja --output /sciezka/wynik \
  --toolchain-dir /sciezka/arm-toolchain/bin --jobs 4
python3 tools/test01_m3b.py pack /sciezka/wynik/klipper.bin /sciezka/wynik/M300APP.M3B
```

Skrypt przygotowuje i modyfikuje prywatną kopię bazy; nie wgrywa firmware.
Przy toolchainie rozdzielonym na pakiety nagłówki newlib muszą być też dostępne
przez `C_INCLUDE_PATH`. Faktyczne środowisko kompilacji opisują
`MCU/TOOLCHAIN.json` i `MCU/FULL_ARM_BUILD.log`.
Metadane i ścieżki kompilacji mogą różnić się między kompilacjami.

`R14_TO_R14_2.patch` odnosi się do zestawu zmienionych źródeł R14, nie do
czystego upstream Klippera. Zmienia siedem plików; główny moduł płyty oraz
implementacja zabezpieczeń STEP pozostają bez zmian.
Funkcjonalna poprawka MCU znajduje się w pliku chłodzenia.
Projekt główny jest objęty GPL-3.0-or-later; patrz `COPYING` w paczce.
