#!/usr/bin/env python3
"""Read-only M300 R14.3 source and compiler smoke tests. Does not flash."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parents[1]
M=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
for item in M['files']:
    f=ROOT/item['path']
    if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=item['sha256']:
        raise SystemExit('FAILED_INTEGRITY: '+item['path'])
board=(ROOT/'SOURCE_MCU/overlay/src/stm32/m300_panel.c').read_text()
assert '0.13.14.3-R15-SCHED-UART8' in board
assert '0.13.14.3-R15-SCHED-UART8' in (ROOT/'SOURCE_MCU/tools/build.py').read_text()
with tempfile.TemporaryDirectory() as td:
    exe=Path(td)/'m300_timer'
    subprocess.run(['gcc','-std=c11','-Wall','-Wextra','-Werror','-O2',
        str(ROOT/'SOURCE_MCU/tests/test_m300_timer_deadline.c'),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
print('PASS_R14_3_SOURCE_INTEGRITY_AND_TIMER_MODEL; ARM_BUILD_NOT_RUN; FLASH_NOT_RUN')
