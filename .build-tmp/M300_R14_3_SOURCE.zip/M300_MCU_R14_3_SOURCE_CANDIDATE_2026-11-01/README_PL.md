# M300 Classic — MCU R14.3 (KANDYDAT ŹRÓDŁOWY; NIE BIN DO WGRANIA)

Data: 2026-11-01. Źródło: sprawdzony pakiet R14.2 oraz poprawki harmonogramu R15.2.

**Ważne: pakiet NIE zawiera nowego, skompilowanego firmware STM32.**
Zawiera źródła i narzędzia do odtworzenia prywatnej kompilacji z kontrolą pochodzenia.
**Nie wgrywać ponownie oryginalnego R14.2 jako R14.3.**

## Cel
Zmniejszyć liczbę przeterminowanych wywołań okresowych zadań (guard 10 ms,
panel 1 ms, lokalny OLED 1 ms, czytnik SD 1 ms aktywny / 5 ms bezczynny),
bez zmian standardowego schedulera kroków, timerów Klippera, UART, SPI,
ADC1/ADC2, wentylatorów, polityk termicznych i bootloadera.
Nowy `m300_sched.h` wyznacza termin względem bieżącego zegara przy spóźnieniu.

**To kandydat, nie udowodnione rozwiązanie `Timer too close`.** Ten błąd
może być wywołany przez spóźnione timery kroków, transmisję lub inne
zadania; modelowe testy nie odtwarzają fizycznych przerwań.

## Kontrole przed kompilacją (komputer Linux/macOS, bez połączenia z drukarką)

```bash
python3 tools/check_sources.py
```

Wynik powinien zawierać `PASS_R14_3_SOURCE_INTEGRITY_AND_TIMER_MODEL`.
Nie zmienia to firmware na drukarce.

## Kompilacja — tylko w osobnym środowisku deweloperskim
Wymagane są: dokładny `UPSTREAM_KLIPPER_PINNED.zip`, SHA-256
`fe4c6a25c370c32f519a008e46e14612ddb116a5ac135146afeee7d0bc4c2bf0`,
kompilator `arm-none-eabi-gcc` i newlib-nano, `make`, Python 3.
Niezależny ZIP upstream nie jest dołączony do tego archiwum.

```bash
cd SOURCE_MCU
python3 tools/build.py --archive /sciezka/UPSTREAM_KLIPPER_PINNED.zip \
  --work /sciezka/oddzielny-katalog-build --output /sciezka/MCU_R14_3_WYNIK \
  --jobs 4
```

`build.py` sprawdza rzeczywisty SHA upstream, konfigurację F103/72MHz,
bezpieczny zakres Flash (start 0x08008000), koniec obrazu przed 0x0803a000,
wektory MSP/Reset, rozmiar RAM, rodziny komend, stałe protokołu i wersję
`0.13.14.3-R15-SCHED-UART8`. Nie flashuje. Wszelkie błędy oznaczają **STOP**.
Do wygenerowania gotowego pliku M3B można użyć `tools/test01_m3b.py pack`,
ale tylko po pełnej walidacji obrazu BIN. Nie wgrywać wyniku automatycznie.

## Warunki przed realnym flashowaniem
- Potwierdzony komplet artefaktów `BIN/ELF/map/dict` i hash całego builda;
- Porównanie wymaganych komend/ABI z działającym R14.2, odczyt `M300_MCU_RELEASE`;
- Własna kopia aktualnego MCU i działająca metoda przywracania R14.2;
- Sprawdzenie autonomicznego chłodzenia i wykrywania awarii w środowisku testowym;
- Brak zakleszczenia osi Z; mechaniczny `Z300` wcześniej nie został zweryfikowany.

Ten pakiet nie zawiera komendy flashowania. Host R15.2 może działać dalej z R14.2.
