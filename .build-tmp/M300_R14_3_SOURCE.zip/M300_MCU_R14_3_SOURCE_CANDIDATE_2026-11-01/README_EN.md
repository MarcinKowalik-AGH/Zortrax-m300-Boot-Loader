# M300 Classic MCU R14.3 — SOURCE CANDIDATE, NOT FLASHABLE RELEASE

This is a source-only reconstruction from the accepted R14.2 MCU kit plus
R15.2 periodic-timer scheduling improvements. No new MCU BIN or M3B exists here.
It does NOT establish that `Timer too close` is fixed on actual hardware.

`python3 tools/check_sources.py` validates source hashes and compiles/runs a
small native deadline model using GCC. The verified upstream source archive
(SHA-256 fe4c6a25c370c32f519a008e46e14612ddb116a5ac135146afeee7d0bc4c2bf0)
plus arm-none-eabi-gcc/newlib-nano is required for the full firmware build.

Build only in an isolated work directory:

```
cd SOURCE_MCU
python3 tools/build.py --archive /path/to/UPSTREAM_KLIPPER_PINNED.zip \
  --work /path/to/private-work --output /path/to/output --jobs 4
```

Full ARM compilation, MCU execution, cooling fault injection and physical Z
clearance tests have NOT been performed. Do not flash the result before
independent checks and confirmation of recovery to R14.2.
